
//: [Previous](@previous)
//: ### Let's Make A Very Simple Birthday Cake
//:
//: Create a ascii picture of a cake using the provided  ingredients and actions
//: Below is the recipe for making the cake
//:

struct UnsaltedButter {
    let sticks: Int
}

struct Egg {
    let quantity: Int
}

struct WholeMilk {
    let cups: Int
}

struct Sugar {
    let cups: Int
}

struct AllPurposeFlour {
    let cups: Int
}

struct VanillaExtract {
    let teaSpoon: Int
}

struct BakingPowder {
    let teaSpoon: Int
}

struct CreamCheeseFrosting {
    let type: String
}

//What can you buy?
func buy(ingredient: AllPurposeFlour) -> AllPurposeFlour {
    print("*                                             *")
    print("                                         *     ")
    print("           *                                   ")
    print("                        *                      ")
    return ingredient
}

//: -What can you crack?
func crack(ingredient: Egg) -> Egg {
    print("    iiiiiiiiiiiiiiiiiii     ")
    print("  |||||||H|A|P|P|Y|||||||    ")
    return ingredient
}
//: - What can you melt?
func melt(ingredient: UnsaltedButter) -> UnsaltedButter {
    print("|\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/|")
    return ingredient
}

//: -What can you measure a cup of?
func measureCupsOf(ingredient: WholeMilk) -> WholeMilk {
    print("|||||||||||||||||||||||||||||")
    return ingredient
}

//: -What can you measure a Teaspoon of?
func measureTeaSpoonsOf(ingredient: BakingPowder) -> BakingPowder {
    print("|||||||||||||||||||||||||||||")
    return ingredient
}

//: -What can you mix?
func mix(ingredient1: WholeMilk, with ingredient2: VanillaExtract) {
     print("|||||||||||||||||||||||||||||")
}

//: -how will you bake?
func bake(at tempeture: Int) {
    print("|,,,,,,,,,,,,,,,,,,,,,,,,,,,|")
}

//: -Is this how you want the cake frosted?
func frost(with frosting: CreamCheeseFrosting) {
     print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
}

//: - ( 1 ) Buy all the ingredients
//: - ( 2 ) Crack the eggs
//: - ( 3 ) Melt the butter
//: - ( 4 ) Measure cups of Milk, Sugar, and All Purpose Flower
//: - ( 5 ) Mix measurements together
//: - ( 6 ) Bake the cake
//: - ( 7) Frost the cake
